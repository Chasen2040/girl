package com.girl.lookbook;
import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.WebView;
import android.webkit.WebResourceRequest;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
public class MainActivity extends Activity {
  WebView w;
  @Override public void onCreate(Bundle b){super.onCreate(b);
    w=new WebView(this);
    w.setWebViewClient(new WebViewClient(){
      @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req){
        Uri uri=req.getUrl(); String scheme=uri.getScheme();
        if("https".equals(scheme)||"http".equals(scheme)){
          try{startActivity(new Intent(Intent.ACTION_VIEW,uri));}catch(Exception ignored){}
          return true;
        }
        return false;
      }
    });
    WebSettings s=w.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);
    s.setAllowFileAccess(true);s.setAllowContentAccess(false);s.setAllowFileAccessFromFileURLs(false);
    s.setAllowUniversalAccessFromFileURLs(false);
    w.setBackgroundColor(0xfff5f3ef);setContentView(w);
    w.loadUrl("file:///android_asset/index.html");
  }
  @Override public void onBackPressed(){if(w.canGoBack())w.goBack();else super.onBackPressed();}
}