#!/usr/bin/env python3
"""Generate a strictly local, offline candidate overview. Does not approve images."""
import argparse,html,json
from pathlib import Path

def generate(manifest,output):
    rows=json.loads(Path(manifest).read_text(encoding='utf-8'))
    if not isinstance(rows,list):raise ValueError('manifest must be JSON array')
    cards=[]
    for i,x in enumerate(rows):
        rel=x.get('local_image','')
        # Local-only paths; never let manifest inject arbitrary web content.
        if not isinstance(rel,str) or not rel.startswith('photos/') or '..' in Path(rel).parts:continue
        e=lambda v:html.escape(str(v or ''),quote=True)
        rights=f"{e(x.get('license'))} · {e(x.get('creator'))}"
        source=x.get('source','')
        source_link=f'<a href="{e(source)}" target="_blank" rel="noopener noreferrer">查看原始来源</a>' if isinstance(source,str) and source.startswith('https://commons.wikimedia.org/') else '来源待确认'
        cards.append(f'<article><a href="{e(rel)}" target="_blank"><img src="{e(rel)}" loading="lazy" alt="候选图 {i+1}"></a><div class="meta"><strong>#{i+1} {e(x.get("name"))}</strong><p>{rights}</p>{source_link}<p>状态：未经人工审核 · 不可发布</p></div></article>')
    page='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>girl · 实拍候选总览</title><style>*{box-sizing:border-box}body{margin:0;background:#f6f4f0;color:#25211f;font-family:system-ui,"Microsoft YaHei",sans-serif}header{padding:24px 5vw;border-bottom:1px solid #ddd}h1{font:600 36px Georgia;margin:0}p{line-height:1.5}small{color:#756f68}.grid{padding:22px 5vw;display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:18px}article{background:white;border:1px solid #e4ded6}img{display:block;aspect-ratio:3/4;object-fit:contain;width:100%;background:#eee}.meta{padding:12px;font-size:12px;overflow-wrap:anywhere}.meta p{margin:7px 0;color:#756f68}a{color:#68504b}</style><header><h1>girl.</h1><p>真实图片候选 · 批量视觉筛选</p><small>全部为未审核候选。此页面只便于总览，不代表已验证女装、无人物、整套完整或可商用。</small></header><main class="grid">'''+''.join(cards)+'''</main></html>'''
    Path(output).write_text(page,encoding='utf-8')
    return len(cards)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--manifest',default='app/src/main/assets/downloaded_candidates.json');ap.add_argument('--output',default='app/src/main/assets/contact_sheet.html');a=ap.parse_args()
    print('offline candidate overview:',generate(a.manifest,a.output))
