#!/usr/bin/env python3
"""Offline synthetic fixtures only. They are NOT real fashion photos."""
import hashlib, tempfile, unittest
from pathlib import Path
from PIL import Image
from publish_approved import validate

class PipelineTest(unittest.TestCase):
 def test_hash_and_review_gate(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp); (root/'photos').mkdir()
   im=Image.new('RGB',(600,800),'white')
   for x in range(60,500):
    for y in range(80,250): im.putpixel((x,y),(x%255,y%255,15))
   im.save(root/'photos'/'test.jpg',quality=89)
   raw=(root/'photos'/'test.jpg').read_bytes();sha=hashlib.sha256(raw).hexdigest()
   row={'id':'fixture','name':'synthetic test, NOT fashion','look_name':'测试套装','season':'秋','outfit_description':'合成样例数据，不是真实的服装摄影','source':'https://commons.wikimedia.org/wiki/File:example.jpg','creator':'TEST ONLY','license':'cc0','local_image':'photos/test.jpg','sha256':sha,'review':{k:'pass' for k in ('real_photo','no_people','women_clothing','complete_outfit','china_2026_relevance')}}
   result,issues=validate([row],root)
   self.assertEqual(len(result),1,issues)
   result,issues=validate([row,row],root)
   self.assertEqual(len(result),1); self.assertTrue(any('duplicate' in x for x in issues))
   row['sha256']='x'
   result,issues=validate([row],root)
   self.assertEqual(len(result),0);self.assertTrue(any('sha256' in x for x in issues))
 def test_metadata_required(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);(root/'photos').mkdir()
   im=Image.new('RGB',(600,800),'white');im.save(root/'photos'/'t.jpg')
   row={'id':'a','source':'https://commons.wikimedia.org','creator':'a','license':'cc0','local_image':'photos/t.jpg','sha256':hashlib.sha256((root/'photos'/'t.jpg').read_bytes()).hexdigest(),'review':{k:'pass' for k in ('real_photo','no_people','women_clothing','complete_outfit','china_2026_relevance')}}
   passed,issues=validate([row],root)
   self.assertFalse(passed);self.assertIn('title',issues[0])
 def test_requires_review_and_rejects_traversal(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp); outside=root.parent/'outside.jpg'
   row={'id':'unreviewed','license':'cc0','source':'https://example.org','creator':'a','local_image':'../outside.jpg','sha256':'none','review':{}}
   result,issues=validate([row],root)
   self.assertFalse(result)
   row['review']={k:'pass' for k in ('real_photo','no_people','women_clothing','complete_outfit','china_2026_relevance')}
   result,issues=validate([row],root)
   self.assertFalse(result)

if __name__=='__main__':unittest.main()
