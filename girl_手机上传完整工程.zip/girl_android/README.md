# girl — real womenswear / source-audited archive

This is an Android WebView app and **curation pipeline**, not a finished 1000-photo catalog. There are currently **0 approved locally packaged photos**. Text outfit combinations are not counted as photos.

## Source → download → visual review → approval

1. Run `python collect_commons.py --limit 100 --out app/src/main/assets` in an environment with internet access and Pillow. It produces local photo files and a JSON file of **unreviewed** candidates. Nothing is auto-approved.
2. Open `app/src/main/assets/index.html` via a local server or in the Android app. Import candidate manifest; examine each local image in the app and export `girl_reviewed_manifest.json`.
3. Put exported JSON into `app/src/main/assets/` and run `python publish_approved.py`. Publication requires **all five manual review fields** to be `pass`, a compatible license with author/source, a local readable image, matching SHA256, minimum resolution and no duplicate SHA256.
4. Only items appearing in `approved_looks.json` are treated as formal looks. The archived CC0 seed is **not** a current-style approved item.
5. GitHub Actions → `Build girl APK` builds a debug APK; the separate `Validate manual reviews and build girl APK` checks reviewed assets before it builds.

The downloader cannot prove items are women's garments or complete outfits. Verify these manually. Respect source licenses, attribution and share-alike obligations; Commons photos are not necessarily modern or trendy. Store image bytes locally to keep approved looks available offline. Shopping platform pictures cannot be bulk republished without appropriate permission.

**No build was executed in the current container**, which has no Android SDK and cannot access remote image hosts.

## V4 verified changes

- `catalog.html` is now the customer-facing gallery. Only rows with `publication_status=approved` from `approved_looks.json` display; 0 reviewed files means an honest empty gallery.
- Corrected downloader's stored-file SHA256 (previously the hash of preprocessed bytes did not match the re-encoded JPEG, blocking publication). `original_sha256` is preserved for provenance.
- Publication performs byte-exact and perceptual near-duplicate screening; similarity checks are cautious and may reject two genuinely different looks for manual review.
- Local offline unit tests: `python test_pipeline.py` (uses synthetic test pictures, never part of released images).
- Source images still cannot be downloaded inside this runtime. The collection workflow can be started by the repository owner in GitHub Actions; that runs on a remote network-enabled runner, then downloads remain **unreviewed** until explicitly approved.

## V5 reviewer artifact (material workflow improvement)

The `Collect licensed photo candidates` workflow now attaches `index.html` in the same extracted folder as `downloaded_candidates.json` and `photos/`, so a reviewer can extract the entire artifact and open `index.html` in a desktop browser. Use the file chooser to import `downloaded_candidates.json` (some browsers block local automatic fetch). The preview uses relative `photos/` paths and works locally once the images are downloaded.

For every candidate, review five mandatory gates and fill **Chinese look name**, **season**, and **outfit description**; export `girl_reviewed_manifest.json`. Place reviewed manifest beside the photos inside the repo, then run `python publish_approved.py` and build APK. A row with no season/name/description cannot be published. The generated JPG must be carried over together with the manifest, otherwise SHA verification fails. No outfit is approved by download alone.

This workspace has no outbound image download or Android SDK; this iteration DOES NOT contain real local photographs or an APK.

## V6 — candidate contact-sheet review

- `make_contact_sheet.py` generates `contact_sheet.html` from **downloaded local candidate images**. It produces no approvals. The file is also included in the `Collect licensed photo candidates` GitHub Actions artifact, beside `index.html`, `photos/`, and `downloaded_candidates.json`.
- Open `contact_sheet.html` after extracting the full artifact to visually screen a batch, then use `index.html` to record the mandatory individual manual checks and Chinese outfit metadata.
- Do not publish shopping-platform images without permission; repository licenses do not automatically license third-party photos.
- The current contact sheet shows **0** candidates because outbound image download is unavailable in this session. No new product photo, approved look, or APK is being claimed.

## V7 — auditable collector execution (2026-11-23)

- `collect_commons.py` now searches ten photography-oriented phrases, rejects missing/unsupported licensing metadata, and records `collection_report.json` (search failures, downloads, corrupt images, duplicates and unresolved cases). Every downloaded file remains unreviewed.
- Collection action uploads the diagnostic report even when no images were downloaded, then explicitly fails; zero-image runs cannot be mistaken for successful ingestion.
- Run locally where Internet is available: `python -m pip install Pillow && python collect_commons.py --limit 100 --out app/src/main/assets`. Then open the downloaded review bundle and manually approve each valid image before release.
- `python -m unittest test_collector test_pipeline test_contact_sheet -v` verifies candidate save/hash, license gate, failure report, publication gate and HTML escaping using synthetic test files only.
- **Actual downloaded photos in this package: 0; approved looks: 0; APK: absent.** Wikimedia Commons search results are not presumed to be modern Chinese women's outfits, and raw images may be ineligible.


## V8：真实摄影来源选片页（2026-11-23）
- Android 启动页面现为 `research.html`，有 7 条原始摄影来源与独立分组、逐个查看入口；不将来源计入正式服装套数。
- `catalog.html` 保持 0 套，真实文件 + 授权 + 人工审核通过后才更新。
- 外部摄影链接仅指向平台原始页面，**未离线下载**；当前运行环境图片下载与 Android APK 编译均不可用。
- 已确认旧照片仅为历史参考，不能充作2026中国女生流行穿搭。
