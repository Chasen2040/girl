#!/usr/bin/env python3
"""Collect licensed photography *candidates* from Wikimedia Commons.
Never declares an image a woman's complete outfit or publishes it automatically.
"""
import argparse, hashlib, html, io, json, re, time, urllib.parse, urllib.request
from pathlib import Path
from PIL import Image, ImageOps, UnidentifiedImageError

API = 'https://commons.wikimedia.org/w/api.php'
HEAD = {'User-Agent': 'girl-lookbook-research/0.7 (Wikimedia Commons educational image curation)'}
QUERIES = [
    '"flat lay" "outfit"', '"flatlay" "clothes"',
    '"women" "outfit" "flat lay"', '"clothing" "flat lay"',
    '"fashion" "flat lay"', '"skirt" "shoes" "bag"',
    '"dress" "handbag" "shoes"', '"knitwear" "flat lay"',
    '"sweater" "skirt" "flat lay"', '"blouse" "skirt" "flat lay"'
]
DISALLOWED = re.compile(r'\b(menswear|male model|man wearing|boy wearing|portrait|illustration|3d render|ai.generated|synthetic image|drawing)\b',re.I)
# Conservative license whitelist. Commons licenses describe source photos,
# not the depicted garment brand; don't ingest unknown or restrictive licenses.
LICENSES = {'cc0','cc0-1.0','public-domain','pd','cc-by-4.0','cc-by-3.0','cc-by-sa-4.0','cc-by-sa-3.0'}

def request_json(params):
    q=urllib.parse.urlencode({'format':'json','formatversion':2,**params})
    with urllib.request.urlopen(urllib.request.Request(API+'?'+q,headers=HEAD),timeout=25) as r:
        return json.load(r)

def clean(value):
    return html.unescape(re.sub(r'<[^>]*>',' ',value or '')).strip()

def metadata(p):
    info=(p.get('imageinfo') or [{}])[0]
    ex=info.get('extmetadata') or {}
    get=lambda k: clean((ex.get(k) or {}).get('value',''))
    license_name=get('LicenseShortName').lower().replace(' ','-')
    if license_name not in LICENSES or not get('Artist'):
        return None
    name=p.get('title','')
    desc=get('ImageDescription')
    if DISALLOWED.search(name+' '+desc):
        return None
    link=info.get('thumburl') or info.get('url')
    if not link or not link.startswith('https://'):
        return None
    return {'id':str(p['pageid']),'name':name.removeprefix('File:'),
            'source':'https://commons.wikimedia.org/wiki/'+urllib.parse.quote(name.replace(' ','_')),
            'image':link,'original_url':info.get('url'),
            'creator':get('Artist'),'license':license_name,'license_url':get('LicenseUrl'),
            'description':desc[:500], 'date':get('DateTimeOriginal') or get('DateTime'),
            'review':{key:'pending' for key in ('real_photo','no_people','women_clothing','complete_outfit','china_2026_relevance')},
            'status':'awaiting_manual_review'}

def collect(out,limit,fetch_json=request_json,fetch_image=None,queries=QUERIES):
    """Injectable network methods enable offline tests; report every outcome."""
    if fetch_image is None:
        def fetch_image(url):
            req=urllib.request.Request(url,headers=HEAD)
            with urllib.request.urlopen(req,timeout=30) as response:
                return response.read(9_000_001)
    out=Path(out);(out/'photos').mkdir(parents=True,exist_ok=True)
    records=[];seen_pages=set();seen_hashes=set()
    stats={'queries_attempted':0,'search_failures':0,'search_results':0,'license_or_metadata_excluded':0,
           'duplicate_pages':0,'download_failures':0,'oversized_or_invalid':0,
           'duplicate_images':0,'downloaded_candidates':0,'approved_looks':0,
           'manual_review_required':True,'warnings':[]}
    for term in queries:
        if len(records)>=limit: break
        stats['queries_attempted']+=1
        try:
            result=fetch_json({'action':'query','generator':'search','gsrsearch':term,
                 'gsrnamespace':6,'gsrlimit':min(50,max(1,limit)),
                 'prop':'imageinfo','iiprop':'url|extmetadata','iiurlwidth':960})
            pages=(result.get('query') or {}).get('pages') or []
        except Exception as exc:
            stats['search_failures']+=1
            stats['warnings'].append(f'{term}: {type(exc).__name__}: {str(exc)[:120]}')
            continue
        stats['search_results']+=len(pages)
        for item in pages:
            if len(records)>=limit: break
            page_id=str(item.get('pageid',''))
            if page_id in seen_pages:
                stats['duplicate_pages']+=1;continue
            seen_pages.add(page_id)
            entry=metadata(item)
            if not entry:
                stats['license_or_metadata_excluded']+=1;continue
            try:
                raw=fetch_image(entry['image'])
                if not raw or len(raw)>9_000_000:
                    stats['oversized_or_invalid']+=1;continue
                im=Image.open(io.BytesIO(raw));im=ImageOps.exif_transpose(im)
                if im.width<400 or im.height<400 or im.width*im.height>40_000_000:
                    stats['oversized_or_invalid']+=1;continue
                im=im.convert('RGB');im.thumbnail((960,1200))
                stream=io.BytesIO();im.save(stream,'JPEG',quality=88,optimize=True)
                saved=stream.getvalue();digest=hashlib.sha256(saved).hexdigest()
                if digest in seen_hashes:
                    stats['duplicate_images']+=1;continue
                seen_hashes.add(digest)
                filename='photos/'+digest[:24]+'.jpg'
                (out/filename).write_bytes(saved)
                entry.update({'local_image':filename,'sha256':digest,
                    'original_sha256':hashlib.sha256(raw).hexdigest(),
                    'width':im.width,'height':im.height})
                records.append(entry)
            except (Exception) as exc:
                stats['download_failures']+=1
                stats['warnings'].append(f'{entry["id"]}: {type(exc).__name__}: {str(exc)[:100]}')
        time.sleep(.1)
    stats['downloaded_candidates']=len(records)
    (out/'downloaded_candidates.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'collection_report.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2),encoding='utf-8')
    return stats

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--limit',type=int,default=100)
    ap.add_argument('--out',default='app/src/main/assets');a=ap.parse_args()
    if a.limit<1 or a.limit>2000:ap.error('--limit must be 1..2000')
    report=collect(a.out,a.limit)
    print(json.dumps(report,ensure_ascii=False,indent=2))
    if report['downloaded_candidates']==0:
        print('ERROR: no downloadable candidates. The collection job is NOT successful.')
        return 2
    print('SUCCESS: candidates saved for review, NOT approved for publication.')
    return 0

if __name__=='__main__':raise SystemExit(main())
