#!/usr/bin/env python3
"""Never publish unreviewed images. Validate source licensing, bytes, hashes, and approvals.
Run after manual inspection, not in the automated photo collector.
"""
from pathlib import Path
from PIL import Image, ImageOps
import argparse,hashlib,json,sys
FIELDS=('real_photo','no_people','women_clothing','complete_outfit','china_2026_relevance')
LICENSES={'cc0','cc0-1.0','cc-by-4.0','cc-by-sa-4.0','cc-by-3.0','cc-by-sa-3.0','pd'}
def dhash(im):
    # 64-bit perceptual hash; manually review flagged near-duplicates.
    sample=ImageOps.exif_transpose(im).convert('L').resize((9,8))
    pixels=list(sample.getdata())
    n=0
    for y in range(8):
        for x in range(8):n=(n<<1)|int(pixels[y*9+x]>pixels[y*9+x+1])
    return n

def validate(rows,root):
    passed=[]; issues=[]; seen=set(); perceptual=[]
    for i,x in enumerate(rows):
        tag=str(x.get('id',i))
        if any(x.get('review',{}).get(k)!='pass' for k in FIELDS):
            issues.append(f'{tag}: review incomplete / failed');continue
        if not str(x.get('look_name','')).strip() or x.get('season') not in ('春','夏','秋','冬') or len(str(x.get('outfit_description','')).strip())<8:
            issues.append(f'{tag}: missing Chinese outfit title, season, or meaningful description');continue
        if (x.get('license') or '').lower().strip() not in LICENSES or not str(x.get('source','')).startswith('https://') or not x.get('creator'):
            issues.append(f'{tag}: license, attribution or source missing');continue
        rel=Path(x.get('local_image') or '')
        try:
            p=(root/rel).resolve()
            if not p.is_relative_to(root.resolve()) or not p.is_file():raise ValueError('not a local image')
            raw=p.read_bytes(); digest=hashlib.sha256(raw).hexdigest()
            if x.get('sha256')!=digest:raise ValueError('sha256 mismatch')
            if digest in seen:raise ValueError('duplicate image')
            with Image.open(p) as im:
                im.verify()
            with Image.open(p) as im:
                if min(im.size)<400:raise ValueError('too small')
                visual_hash=dhash(im)
            if any((visual_hash ^ other).bit_count() <= 4 for other in perceptual):
                raise ValueError('near-duplicate image; manual disambiguation required')
            seen.add(digest);perceptual.append(visual_hash)
            passed.append({k:v for k,v in x.items() if k!='review'}|{'name':x['look_name'],'description':x['outfit_description'],'review':x['review'],'publication_status':'approved'})
        except Exception as e:issues.append(f'{tag}: {e}')
    return passed,issues

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--manifest',default='app/src/main/assets/girl_reviewed_manifest.json');ap.add_argument('--assets',default='app/src/main/assets');ap.add_argument('--output',default='app/src/main/assets/approved_looks.json');a=ap.parse_args()
    root=Path(a.assets)
    if not Path(a.manifest).exists():print('No reviewed manifest. 0 approved; no changes.',file=sys.stderr);return 1
    rows=json.loads(Path(a.manifest).read_text(encoding='utf8'))
    if not isinstance(rows,list):raise ValueError('manifest must be list')
    passed,issues=validate(rows,root)
    Path(a.output).write_text(json.dumps(passed,ensure_ascii=False,indent=2),encoding='utf8')
    print(f'approved={len(passed)} excluded={len(issues)}')
    for issue in issues:print('EXCLUDED',issue)
    return 0
if __name__=='__main__':sys.exit(main())
