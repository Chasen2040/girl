import json,tempfile,unittest
from pathlib import Path
from make_contact_sheet import generate
class ContactSheetTests(unittest.TestCase):
 def test_only_local_paths_and_escape(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d); m=root/'x.json';out=root/'out.html'
   m.write_text(json.dumps([{'name':'<script>alert(1)</script>','local_image':'photos/test.jpg','license':'cc0','creator':'Someone','source':'https://commons.wikimedia.org/wiki/File:test.jpg'},{'name':'unsafe','local_image':'../bad.jpg'}]),encoding='utf8')
   self.assertEqual(generate(m,out),1)
   txt=out.read_text();self.assertNotIn('<script>',txt);self.assertIn('&lt;script&gt;',txt);self.assertNotIn('../bad.jpg',txt)
if __name__=='__main__':unittest.main()
