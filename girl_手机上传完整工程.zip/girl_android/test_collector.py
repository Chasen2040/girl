"""All fixtures are synthetic and must never appear in the public catalog."""
import hashlib, io, json, tempfile, unittest
from pathlib import Path
from PIL import Image
from collect_commons import collect,metadata

class CollectorTest(unittest.TestCase):
    def sample(self):
        page={'pageid':12,'title':'File:Example flat lay outfit.jpg','imageinfo':[{'url':'https://example.test/example.jpg',
          'extmetadata':{'LicenseShortName':{'value':'CC0'},'Artist':{'value':'Test photographer'},
             'ImageDescription':{'value':'A test photo'}}}]}
        im=Image.new('RGB',(600,800),'white');s=io.BytesIO();im.save(s,'JPEG');return page,s.getvalue()
    def test_local_file_integrity_and_no_autoapproval(self):
        page,raw=self.sample()
        with tempfile.TemporaryDirectory() as tmp:
            report=collect(tmp,5,fetch_json=lambda _: {'query':{'pages':[page]}},
                           fetch_image=lambda _:raw,queries=['flat lay'])
            self.assertEqual(report['downloaded_candidates'],1)
            self.assertEqual(report['approved_looks'],0)
            x=json.loads((Path(tmp)/'downloaded_candidates.json').read_text())[0]
            self.assertEqual(x['status'],'awaiting_manual_review')
            self.assertTrue(all(v=='pending' for v in x['review'].values()))
            self.assertEqual(x['sha256'],hashlib.sha256((Path(tmp)/x['local_image']).read_bytes()).hexdigest())
    def test_reports_network_failure(self):
        with tempfile.TemporaryDirectory() as tmp:
            def fail(_):raise OSError('network unavailable')
            report=collect(tmp,2,fetch_json=fail,queries=['one','two'])
            self.assertEqual(report['search_failures'],2)
            self.assertEqual(report['downloaded_candidates'],0)
            self.assertTrue((Path(tmp)/'collection_report.json').exists())
    def test_unlicensed_image_excluded(self):
        p,_=self.sample();p['imageinfo'][0]['extmetadata']['LicenseShortName']['value']='All rights reserved'
        self.assertIsNone(metadata(p))
if __name__=='__main__':unittest.main()
